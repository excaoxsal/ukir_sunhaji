


<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <a href="<?php echo e(route('provinsi.create')); ?>" class="btn btn-success">Tambah Provinsi</a>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Daftar Provinsi</h3>
              </div>
              <!-- /.card-header -->
              
              <div class="card-body"> 
                <table  class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Nama Provinsi</th>
                    <th>Harga</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>
                    
                    <td><?php echo e($p->nama_provinsi); ?></td>
                    <td><?php echo e($p->price); ?></td>
                    <td><form action="<?php echo e(route('provinsi.destroy',$p->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a class="btn btn-primary" href="<?php echo e(route('provinsi.edit',$p->id)); ?>">Edit</a>
                        <button class="btn btn-danger" type="submit">Delete</button></form>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    
<script type="text/javascript">
function submitform()
{
   if(document.orderForm.onsubmit &&
   !document.orderForm.onsubmit())
   {
   return;
   }
   document.orderForm.submit();
}
</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/provinsi/index.blade.php ENDPATH**/ ?>



<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h1 class="card-title text-bold">My Order</h1>
              </div>
              <!-- /.card-header -->
              <div class="card-body"> 
                <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    
                    <th>Gambar Produk</th>
                    <th>Nama Barang</th>
                    <th>Harga</th>
                    <th>Berat</th>
                    <th>Tanggal Pemesanan</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $myorder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td><img src="<?php echo e(url('product_files/'.$p->picture)); ?>" alt="gambar produk" width="150" height="150"></td>
                    <td><?php echo e($p->name); ?></td>
                    <td>Rp.<?php echo e($p->price); ?></td>
                    <td><?php echo e($p->weight); ?></td>
                    <td><?php echo e($p->created_at); ?></td>
                    <td><?php echo e($p->status); ?></td>
                    <td>
                    <?php if(count($alamat) == 0): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('alamat.create',$p->id)); ?>">Isi Alamat Sekarang</a>
                    <?php else: ?>
                    <a class="btn btn-primary" href="<?php echo e(route('struk.show',$p->id)); ?>">Bayar Sekarang</a>
                    <?php endif; ?>
                    <input type='number' name='order' value="<?php echo e($p->id); ?>" class="invisible" />
                    <form action="<?php echo e(url('/cancelOrder')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="id" value="<?php echo e($p->id); ?>"><button type="submit" class="btn btn-danger">Batalkan Pesanan</button>
                    </form>
                  </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    
<script type="text/javascript">
function submitform()
{
   if(document.orderForm.onsubmit &&
   !document.orderForm.onsubmit())
   {
   return;
   }
   document.orderForm.submit();
}
</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.konsumen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/konsumen/order.blade.php ENDPATH**/ ?>



<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Status Orders</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href=""> Back</a>
        </div>
    </div>
</div>


<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(url('edit/saveStatus')); ?>" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="hidden"  class="form-control" name="orderId" value="<?php echo e($p->id); ?>"  id="tfDefault">
  <div class="card-body">
    <div class="form-group">
      <label for="exampleInputEmail1">Status Pengiriman</label>
      <input type="name" name="status" value="<?php echo e($p->status); ?>" class="form-control" placeholder="Product Name">
    </div>
  </div>
  <!-- /.card-body -->

  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
  
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.konsumen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/orders/edit.blade.php ENDPATH**/ ?>
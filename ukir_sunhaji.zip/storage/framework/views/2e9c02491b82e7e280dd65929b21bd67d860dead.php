


<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tambah Provinsi</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <form action="<?php echo e(route('provinsi.update',$p->id)); ?>" method="post"enctype="multipart/form-data">
                  <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                  <label for="Nama Provinsi">Nama Provinsi</label>
                  <input type="text" name="namaprovinsi" value="<?php echo e($p->nama_provinsi); ?>" placeholder="Nama Provinsi" class="form-control">
                  <label for="Nama Provinsi">Ongkos Kirim</label>
                  <input type="number" name="price" value="<?php echo e($p->price); ?>" placeholder="Ongkir" class="form-control">
                  <button type="submit" class="btn btn-success">Submit</button>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/provinsi/edit.blade.php ENDPATH**/ ?>
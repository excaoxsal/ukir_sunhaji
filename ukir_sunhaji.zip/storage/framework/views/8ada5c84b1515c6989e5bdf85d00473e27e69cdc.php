


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Product</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
            </div>
        </div>
    </div>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>



<form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="card-body">
    <div class="form-group">
      <label for="exampleInputEmail1">Product Name</label>
      <input type="name" name="name" class="form-control" placeholder="Product Name">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Detail</label>
      <textarea class="form-control" style="height:150px" name="detail" placeholder="Detail"></textarea>
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Price</label>
      <input type="number" name="price" class="form-control" placeholder="Price">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Weight</label>
      <input type="number" name="weight" class="form-control" placeholder="Weight">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Stock</label>
      <input type="number" name="stock" class="form-control" placeholder="Stock">
    </div>
    <div class="form-group">
      <label for="exampleInputFile">Input Pictures</label>
      <div class="input-group">
        <div class="form-group">
            <div class="custom-file">
              <input type="file" class="form-control" id="tf2" value="<?php echo e(old('file')); ?>" name="file" >
            </div>
          </div><!-- /.form-group -->
      </div>
    </div>
  </div>
  <!-- /.card-body -->

  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
  
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/products/create.blade.php ENDPATH**/ ?>
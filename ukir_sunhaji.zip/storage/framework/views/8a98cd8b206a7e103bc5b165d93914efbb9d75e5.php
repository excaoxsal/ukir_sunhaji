


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Update Address</h2>
        </div>
        
    </div>
</div>


<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php $__currentLoopData = $almat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(url('edit/update')); ?>" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="text"  class="form-control" name="alamat" value="<?php echo e($p->id); ?>" hidden="true" id="tfDefault">
  <div class="card-body">
    <div class="form-group">
      <label for="exampleInputEmail1">Nama Penerima</label>
      <input type="name" name="name" value="<?php echo e($p['nama']); ?>" class="form-control" placeholder="Product Name">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Email</label>
      <input type="email" name="email" value="<?php echo e($p['email']); ?>" class="form-control" placeholder="Email">
      
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Nomor telepon yg dapat dihubungi</label>
      <input type="number" name="phonenumber" class="form-control" value="<?php echo e($p['phonenumber']); ?>" placeholder="Nomor Telepon">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Provinsi</label>
        <select selected="form-control select2" style="width: 100%;" name="provinsi" class="custom-select" id="selDefault"selected>
        <option selected>.....
        <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option name="provinsi" value="<?php echo e($pv['id']); ?>" ><?php echo e($pv['nama_provinsi']); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Kota/Kabupaten</label>
      <input type="text" name="region" class="form-control" value="<?php echo e($p['region']); ?>" placeholder="Kota/Kabupaten">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Alamat Lengkap</label>
      <textarea class="form-control" style="height:150px" name="fulladdress" placeholder="Alamat Lengkap"></textarea>
    </div>
  </div>
  <!-- /.card-body -->

  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
  
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.konsumen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/alamat/edit.blade.php ENDPATH**/ ?>



<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="container-fluid">
        <?php if(count($alamat) == 0): ?>
            <a class="btn btn-success" href="<?php echo e(route('alamat.create')); ?>">Create Address</a>
        <?php endif; ?>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Alamatku</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th></th>
                    <th>Nama Penerima</th>
                    <th>email</th>
                    <th>Provinsi</th>
                    <th>Kabupaten</th>
                    <th>No HP</th>
                    <th>Alamat Lengkap</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $alamat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      
                    </td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->email); ?></td>
                    <td><?php echo e($a->nama_provinsi); ?></td>
                    <td><?php echo e($a->region); ?></td>
                    <td><?php echo e($a->phonenumber); ?></td>
                    <td><?php echo e($a->fulladdress); ?></td>
                    <td>
                        
                            <a class="btn btn-primary" href="<?php echo e(route('alamat.edit',$a->id)); ?>">Edit</a>
                        
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    
<script type="text/javascript">
function submitform()
{
   if(document.orderForm.onsubmit &&
   !document.orderForm.onsubmit())
   {
   return;
   }
   document.orderForm.submit();
}
</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.konsumen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/alamat/index.blade.php ENDPATH**/ ?>
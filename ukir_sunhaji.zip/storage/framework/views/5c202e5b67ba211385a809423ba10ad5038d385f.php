


<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Orders</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body"> 
                <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Gambar Produk</th>
                    <th>Nama Barang</th>
                    <th>Harga</th>
                    <th>Berat</th>
                    <th>Tanggal Pemesanan</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><img src="<?php echo e(url('product_files/'.$p->picture)); ?>" alt="gambar produk" width="150" height="150"></td>
                    <td><?php echo e($p->name); ?></td>
                    <td>Rp.<?php echo e($p->price); ?></td>
                    <td><?php echo e($p->weight); ?></td>
                    <td><?php echo e($p->created_at); ?></td>
                    <td><?php echo e($p->status); ?></td>
                    <td>
                      <a class="btn btn-success" href="<?php echo e(route('struk.show',$p->idorder)); ?>">Cek Struk</a>
                      <form name="orderForm" enctype="multipart/form-data" action="<?php echo e(route('orders.edit',$p->idorder)); ?>">
                    <input type='hidden' name='order' value="<?php echo e($p->id); ?>" class="invisible" /><button type="submit" class="btn btn-primary">Change Status</button></form>
                    <form action="<?php echo e(route('orders.destroy',$p->idorder)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger">Delete</button></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    
<script type="text/javascript">
function submitform()
{
   if(document.orderForm.onsubmit &&
   !document.orderForm.onsubmit())
   {
   return;
   }
   document.orderForm.submit();
}
</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Program Files\XAMPP\htdocs\ukir_sunhaji\resources\views/orders/show.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class konsumen extends Controller
{
    //
}
